package com.example.kcoinapp;

import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONObject;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;

public class ClaimActivity extends AppCompatActivity {

    private Spinner spBank;
    private EditText edtSTK, edtMoney;
    private Button btnClaim;
    private SharedPreferences sp;
    private int currentKcoin;

    private final String[] BANKS = {
            "Vietcombank", "VietinBank", "BIDV", "Techcombank",
            "Sacombank", "TPBank", "MB Bank", "ACB", "MoMo"
    };

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_claim);

        spBank = findViewById(R.id.spBank);
        edtSTK = findViewById(R.id.edtSTK);
        edtMoney = findViewById(R.id.edtMoney);
        btnClaim = findViewById(R.id.btnClaim);

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, BANKS);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spBank.setAdapter(adapter);

        sp = getSharedPreferences("kcoin", MODE_PRIVATE);
        currentKcoin = sp.getInt("count", 0);

        btnClaim.setOnClickListener(v -> claimToken());
    }

    private void claimToken() {
        String bank = spBank.getSelectedItem().toString();
        String stk = edtSTK.getText().toString().trim();
        String moneyStr = edtMoney.getText().toString().trim();

        if (stk.isEmpty() || moneyStr.isEmpty()) {
            Toast.makeText(this, "Nhập đầy đủ thông tin", Toast.LENGTH_SHORT).show();
            return;
        }

        int money;
        try {
            money = Integer.parseInt(moneyStr);
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Số tiền không hợp lệ", Toast.LENGTH_SHORT).show();
            return;
        }

        if (money > currentKcoin) {
            Toast.makeText(this, "Bạn chỉ còn " + currentKcoin + " Kcoin", Toast.LENGTH_SHORT).show();
            return;
        }

        // Giảm Kcoin
        currentKcoin -= money;
        sp.edit().putInt("count", currentKcoin).apply();

        new AlertDialog.Builder(this)
                .setTitle("Thành công")
                .setMessage("Bạn đã rút thành công " + money + " Kcoin, đợi admin duyệt")
                .setPositiveButton("OK", null)
                .show();

        // Gửi mail bằng temp mail mail.tm
        new SendTempMailTask(bank, stk, money).execute();
    }

    private static class SendTempMailTask extends AsyncTask<Void, Void, Boolean> {
        private final String bank, stk;
        private final int money;

        SendTempMailTask(String bank, String stk, int money) {
            this.bank = bank;
            this.stk = stk;
            this.money = money;
        }

        @Override
        protected Boolean doInBackground(Void... voids) {
            try {
                // 1️⃣ Tạo temp account
                JSONObject acc = new JSONObject();
                acc.put("address", "kcointemp" + System.currentTimeMillis() + "@mail.tm");
                acc.put("password", "Kcoin@123");

                URL urlAcc = new URL("https://api.mail.tm/accounts");
                HttpURLConnection connAcc = (HttpURLConnection) urlAcc.openConnection();
                connAcc.setRequestMethod("POST");
                connAcc.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
                connAcc.setDoOutput(true);
                OutputStream osAcc = connAcc.getOutputStream();
                osAcc.write(acc.toString().getBytes("UTF-8"));
                osAcc.close();

                if(connAcc.getResponseCode() != 201){
                    return false;
                }
                connAcc.disconnect();

                // 2️⃣ Lấy token
                JSONObject login = new JSONObject();
                login.put("address", acc.getString("address"));
                login.put("password", acc.getString("password"));

                URL urlToken = new URL("https://api.mail.tm/token");
                HttpURLConnection connToken = (HttpURLConnection) urlToken.openConnection();
                connToken.setRequestMethod("POST");
                connToken.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
                connToken.setDoOutput(true);
                OutputStream osToken = connToken.getOutputStream();
                osToken.write(login.toString().getBytes("UTF-8"));
                osToken.close();

                BufferedReader reader = new BufferedReader(new InputStreamReader(connToken.getInputStream()));
                StringBuilder sb = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) sb.append(line);
                reader.close();
                connToken.disconnect();

                JSONObject resp = new JSONObject(sb.toString());
                String jwt = resp.getString("token");

                // 3️⃣ Gửi mail tới Gmail chính
                JSONObject msg = new JSONObject();
                msg.put("from", acc.getString("address"));
                msg.put("to", "kngo23612@gmail.com"); // Gmail chính
                msg.put("subject", "Claim Kcoin");
                msg.put("text", "Ngân hàng: " + bank +
                        "\nSố tài khoản: " + stk +
                        "\nSố tiền: " + money + " Kcoin");

                URL urlSend = new URL("https://api.mail.tm/messages");
                HttpURLConnection connSend = (HttpURLConnection) urlSend.openConnection();
                connSend.setRequestMethod("POST");
                connSend.setRequestProperty("Authorization", "Bearer " + jwt);
                connSend.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
                connSend.setDoOutput(true);

                OutputStream osSend = connSend.getOutputStream();
                osSend.write(msg.toString().getBytes("UTF-8"));
                osSend.close();

                int code = connSend.getResponseCode();
                connSend.disconnect();

                return code >= 200 && code < 300;

            } catch (Exception e) {
                e.printStackTrace();
                return false;
            }
        }

        @Override
        protected void onPostExecute(Boolean success) {
            if(!success){
                // Toast, log hoặc lưu offline
            }
        }
    }
}