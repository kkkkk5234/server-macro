package com.example.kcoinapp;

import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import org.json.JSONArray;
import org.json.JSONObject;

public class KeyActivity extends AppCompatActivity {

    EditText keyInput;
    Button checkButton;

    private final String GITHUB_JSON_URL = "https://raw.githubusercontent.com/kkkkk5234/toolgopv1/main/key.json";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_key);

        keyInput = findViewById(R.id.editTextKey);
        checkButton = findViewById(R.id.buttonCheck);

        checkButton.setOnClickListener(v -> {
            String userKey = keyInput.getText().toString().trim();
            if(userKey.isEmpty()){
                Toast.makeText(this, "Nhập key trước đã!", Toast.LENGTH_SHORT).show();
            } else {
                new CheckKeyTask().execute(userKey);
            }
        });
    }

    private class CheckKeyTask extends AsyncTask<String, Void, Boolean> {
        String keyType = "";

        @Override
        protected Boolean doInBackground(String... params) {
            String userKey = params[0];
            try {
                URL url = new URL(GITHUB_JSON_URL);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET");
                conn.setConnectTimeout(5000);
                conn.setReadTimeout(5000);

                BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                StringBuilder sb = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null){
                    sb.append(line);
                }
                reader.close();
                conn.disconnect();

                JSONObject json = new JSONObject(sb.toString());
                JSONArray freeKeys = json.getJSONArray("free_keys");
                JSONArray vipKeys = json.getJSONArray("vip_keys");

                for(int i=0; i<freeKeys.length(); i++){
                    if(userKey.equals(freeKeys.getString(i))){
                        keyType = "FREE";
                        return true;
                    }
                }
                for(int i=0; i<vipKeys.length(); i++){
                    if(userKey.equals(vipKeys.getString(i))){
                        keyType = "VIP";
                        return true;
                    }
                }

            } catch (Exception e){
                e.printStackTrace();
                return false;
            }

            return false;
        }

        @Override
        protected void onPostExecute(Boolean valid) {
            if(valid){
                Toast.makeText(KeyActivity.this, "Key hợp lệ: " + keyType, Toast.LENGTH_SHORT).show();
                // TODO: Chuyển sang MainActivity
                // startActivity(new Intent(KeyActivity.this, MainActivity.class));
                // finish();
            } else {
                Toast.makeText(KeyActivity.this, "Key không hợp lệ!", Toast.LENGTH_SHORT).show();
            }
        }
    }
}}