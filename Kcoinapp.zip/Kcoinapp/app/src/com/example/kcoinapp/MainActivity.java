package com.example.kcoinapp;

import android.animation.ObjectAnimator;
import android.content.*;
import android.os.Bundle;
import android.view.animation.BounceInterpolator;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private static final int MAX = 1000;
    private int count;
    private ProgressBar bar;
    private TextView txt;
    private SharedPreferences sp;
    private ImageView coin;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);

        bar = findViewById(R.id.progress);
        txt = findViewById(R.id.txtCount);
        coin = findViewById(R.id.imgCoin); // ImageView đồng xu
        bar.setMax(MAX);

        sp = getSharedPreferences("kcoin", MODE_PRIVATE);
        String today = String.valueOf(System.currentTimeMillis() / 86400000);
        if (!today.equals(sp.getString("day", ""))) {
            sp.edit().putString("day", today).putInt("count", 0).apply();
        }
        count = sp.getInt("count", 0);
        update();

        findViewById(R.id.btnClick).setOnClickListener(v -> clickCoin());

        findViewById(R.id.btnWallet).setOnClickListener(v -> {
            startActivity(new Intent(this, ClaimActivity.class));
        });
    }

    private void clickCoin() {
        if (count >= MAX) {
            Toast.makeText(this, "Hết lượt hôm nay", Toast.LENGTH_SHORT).show();
            return;
        }

        count++;
        sp.edit().putInt("count", count).apply();
        update();

        // Animation nhảy đồng xu
        ObjectAnimator animator = ObjectAnimator.ofFloat(coin, "translationY", 0f, -200f, 0f);
        animator.setDuration(500);
        animator.setInterpolator(new BounceInterpolator());
        animator.start();
    }

    private void update() {
        bar.setProgress(count);
        txt.setText(count + "/" + MAX + " click/day");
    }
}